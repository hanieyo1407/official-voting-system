import { Position, VotingStats, AdminUser, AuditLogEntry } from './types';

// Set mock dates for the election countdown timer
const now = new Date();
// Election starts in 1 day from now
export const ELECTION_START_DATE = new Date(now.getTime() + 1 * 24 * 60 * 60 * 1000);
// Election ends 3 days from now (lasts for 2 days)
export const ELECTION_END_DATE = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);


export const INITIAL_POSITIONS_DATA: Position[] = [
  {
    id: 'president',
    name: 'Student Union President',
    candidates: [
      { id: 'pres-1', name: 'John Banda', photoUrl: 'https://picsum.photos/seed/pres1/200/200', faculty: 'Engineering', manifesto: 'To foster unity, transparency, and progress for all students. My administration will focus on improving academic resources and student welfare.' },
      { id: 'pres-2', name: 'Mary Chirwa', photoUrl: 'https://picsum.photos/seed/pres2/200/200', faculty: 'Business', manifesto: 'My goal is to be the voice of the students. I will champion for lower fees, better campus facilities, and more student-led initiatives.' },
      { id: 'pres-3', name: 'Peter Mwale', photoUrl: 'https://picsum.photos/seed/pres3/200/200', faculty: 'Science', manifesto: 'Innovation and technology will be at the forefront of my leadership. I plan to introduce a new student portal and improve campus Wi-Fi.' },
    ],
  },
  {
    id: 'vice-president',
    name: 'Vice President',
    candidates: [
      { id: 'vp-1', name: 'Alice Phiri', photoUrl: 'https://picsum.photos/seed/vp1/200/200', faculty: 'Education', manifesto: 'Supporting the president and ensuring all student committees are effective and efficient. I will focus on inter-faculty collaboration.' },
      { id: 'vp-2', name: 'David Kaluwa', photoUrl: 'https://picsum.photos/seed/vp2/200/200', faculty: 'Humanities', manifesto: 'My commitment is to enhance student life through better social events, clubs, and societies. I will work to make our campus more vibrant.' },
    ],
  },
];

export const MOCK_OVERALL_STATS: VotingStats = {
    totalVoters: 1247,
    totalVotesCast: 523,
    voterTurnout: 41.9,
    positionsWithStats: [
        {
            positionName: 'Student Union President',
            totalVotes: 523,
            candidates: [
                { candidateName: 'John Banda', voteCount: 245, votePercentage: 46.8 },
                { candidateName: 'Mary Chirwa', voteCount: 178, votePercentage: 34.0 },
                { candidateName: 'Peter Mwale', voteCount: 100, votePercentage: 19.1 },
            ],
        },
        {
            positionName: 'Vice President',
            totalVotes: 510,
            candidates: [
                { candidateName: 'Alice Phiri', voteCount: 310, votePercentage: 60.8 },
                { candidateName: 'David Kaluwa', voteCount: 200, votePercentage: 39.2 },
            ],
        },
    ],
    overallStats: {
        totalPositions: 2,
        totalCandidates: 5,
    },
};


export const MOCK_VOTE_VERIFICATION_CODE = 'SJBU-8X4K-9P2L';

export const MOCK_ADMIN_STATS = {
    totalRegistered: 1247,
    votesCast: 523,
    turnout: 41.9,
    currentlyVoting: 12,
    avgVoteTime: 3.5,
    hourlyTurnout: [
        { hour: '8-9 AM', votes: 87 },
        { hour: '9-10 AM', votes: 123 },
        { hour: '10-11 AM', votes: 145 },
        { hour: '11-12 PM', votes: 98 },
        { hour: '12-1 PM', votes: 70 },
    ],
    stationStatus: [
        { name: 'Main Campus', status: 'Online', votes: 234, },
        { name: 'Science Faculty', status: 'Online', votes: 156, },
        { name: 'Student Center', status: 'Online', votes: 133, },
    ]
};

export const MOCK_ADMIN_USERS: AdminUser[] = [
    { id: 'user-1', username: 'super.admin', role: 'super_admin', password: 'password123' },
    { id: 'user-2', username: 'standard.admin', role: 'admin', password: 'password123' },
    { id: 'user-3', username: 'audit.moderator', role: 'moderator', password: 'password123' },
    { id: 'user-4', username: 'jane.doe', role: 'admin', password: 'password123' },
];

export const MOCK_AUDIT_LOG_DATA: AuditLogEntry[] = [
  { id: 'log-1', timestamp: new Date(Date.now() - 2 * 60 * 1000), adminUsername: 'super.admin', action: 'LOGIN_SUCCESS', details: 'User logged in successfully.', ipAddress: '192.168.1.1' },
  { id: 'log-2', timestamp: new Date(Date.now() - 5 * 60 * 1000), adminUsername: 'super.admin', action: 'POSITION_CREATED', details: 'Created new position: "Treasurer".', ipAddress: '192.168.1.1' },
  { id: 'log-3', timestamp: new Date(Date.now() - 10 * 60 * 1000), adminUsername: 'standard.admin', action: 'CANDIDATE_UPDATED', details: 'Updated candidate "Mary Chirwa" for "Student Union President".', ipAddress: '203.0.113.25' },
  { id: 'log-4', timestamp: new Date(Date.now() - 15 * 60 * 1000), adminUsername: 'audit.moderator', action: 'LOGIN_FAILED', details: 'Failed login attempt.', ipAddress: '198.51.100.10' },
  { id: 'log-5', timestamp: new Date(Date.now() - 25 * 60 * 1000), adminUsername: 'super.admin', action: 'USER_ROLE_CHANGED', details: 'Changed role of "jane.doe" to "moderator".', ipAddress: '192.168.1.1' },
  { id: 'log-6', timestamp: new Date(Date.now() - 30 * 60 * 1000), adminUsername: 'standard.admin', action: 'CANDIDATE_DELETED', details: 'Deleted candidate "Peter Mwale" from "Student Union President".', ipAddress: '203.0.113.25' },
  { id: 'log-7', timestamp: new Date(Date.now() - 45 * 60 * 1000), adminUsername: 'super.admin', action: 'SETTINGS_UPDATED', details: 'Changed election end date.', ipAddress: '192.168.1.1' },
  { id: 'log-8', timestamp: new Date(Date.now() - 60 * 60 * 1000), adminUsername: 'standard.admin', action: 'LOGIN_SUCCESS', details: 'User logged in successfully.', ipAddress: '203.0.113.25' },
];
