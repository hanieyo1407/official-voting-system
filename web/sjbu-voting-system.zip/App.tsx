import React, { useState, useEffect } from 'react';
import { Page, Position, Candidate, AdminUser, ElectionStatus } from './types';
import { INITIAL_POSITIONS_DATA, MOCK_ADMIN_USERS, ELECTION_START_DATE, ELECTION_END_DATE } from './constants';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import AuthenticationPage from './pages/AuthenticationPage';
import VotingPage from './pages/VotingPage';
import VoteSuccessPage from './pages/VoteSuccessPage';
import VerificationPage from './pages/VerificationPage';
import AdminDashboard from './pages/AdminDashboard';
import AdminLoginPage from './pages/AdminLoginPage';
import OfficialResultsPage from './pages/OfficialResultsPage';
import LiveResultsPage from './pages/LiveResultsPage';
import WinnersPage from './pages/WinnersPage';
import IntroPage from './pages/IntroPage';
import Card from './components/Card';
import Button from './components/Button';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>(Page.Intro);
  const [verificationCode, setVerificationCode] = useState<string>('');
  const [positions, setPositions] = useState<Position[]>(INITIAL_POSITIONS_DATA);
  const [currentUser, setCurrentUser] = useState<AdminUser | null>(null);
  const [adminUsers, setAdminUsers] = useState<AdminUser[]>(MOCK_ADMIN_USERS);
  const [electionStatus, setElectionStatus] = useState<ElectionStatus>('PRE_ELECTION');
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  
  const [electionStartDate, setElectionStartDate] = useState(ELECTION_START_DATE);
  const [electionEndDate, setElectionEndDate] = useState(ELECTION_END_DATE);


  // Effect to handle online/offline status changes globally
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);
  
  // --- Handler for starting election countdown ---
  const handleStartCountdown = (hours: number) => {
    const now = new Date();
    // Election starts `hours` from now
    const newStartDate = new Date(now.getTime() + hours * 60 * 60 * 1000);
    // Election lasts for 2 days
    const newEndDate = new Date(newStartDate.getTime() + 2 * 24 * 60 * 60 * 1000);
    
    setElectionStartDate(newStartDate);
    setElectionEndDate(newEndDate);
  };


  // --- Handlers for Admin Auth ---
  const handleAdminLogin = (user: AdminUser) => {
    setCurrentUser(user);
    setCurrentPage(Page.Admin);
  };

  const handleAdminLogout = () => {
    setCurrentUser(null);
    setCurrentPage(Page.Home);
  };
  
  // --- Handlers for Positions ---
  const handleAddPosition = (position: Omit<Position, 'id' | 'candidates'>) => {
    const newPosition: Position = {
      ...position,
      id: `pos-${new Date().getTime()}`,
      candidates: [],
    };
    setPositions([...positions, newPosition]);
  };

  const handleUpdatePosition = (updatedPosition: Position) => {
    setPositions(positions.map(p => p.id === updatedPosition.id ? { ...p, name: updatedPosition.name } : p));
  };
  
  const handleDeletePosition = (positionId: string) => {
    setPositions(positions.filter(p => p.id !== positionId));
  };

  // --- Handlers for Candidates ---
  const handleAddCandidate = (positionId: string, candidate: Omit<Candidate, 'id'>) => {
    const newCandidate: Candidate = {
      ...candidate,
      id: `cand-${new Date().getTime()}`,
    };
    setPositions(positions.map(p => {
      if (p.id === positionId) {
        return { ...p, candidates: [...p.candidates, newCandidate] };
      }
      return p;
    }));
  };

  const handleUpdateCandidate = (positionId: string, updatedCandidate: Candidate) => {
     setPositions(positions.map(p => {
      if (p.id === positionId) {
        return { ...p, candidates: p.candidates.map(c => c.id === updatedCandidate.id ? updatedCandidate : c) };
      }
      return p;
    }));
  };

  const handleDeleteCandidate = (positionId: string, candidateId: string) => {
    setPositions(positions.map(p => {
      if (p.id === positionId) {
        return { ...p, candidates: p.candidates.filter(c => c.id !== candidateId) };
      }
      return p;
    }));
  };

  // --- Handlers for Users ---
    const handleAddUser = (user: Omit<AdminUser, 'id'>) => {
        const newUser: AdminUser = {
            ...user,
            id: `user-${new Date().getTime()}`,
        };
        setAdminUsers([...adminUsers, newUser]);
    };
    
    const handleUpdateUser = (updatedUser: AdminUser) => {
        setAdminUsers(adminUsers.map(u => u.id === updatedUser.id ? { ...u, ...updatedUser } : u));
    };

    const handleDeleteUser = (userId: string) => {
        // Prevent deleting the currently logged-in user
        if (currentUser?.id === userId) {
            alert("You cannot delete the currently logged-in user.");
            return;
        }
        setAdminUsers(adminUsers.filter(u => u.id !== userId));
    };


  const ElectionStatusSimulator = () => (
      <div className="fixed bottom-4 right-4 bg-white p-3 rounded-lg shadow-2xl z-50 border">
          <h4 className="text-sm font-bold text-dmi-blue-900 mb-2">Election Status Simulator</h4>
          <div className="flex space-x-2">
              <Button size="sm" variant={electionStatus === 'PRE_ELECTION' ? 'primary' : 'secondary'} onClick={() => setElectionStatus('PRE_ELECTION')}>Pre</Button>
              <Button size="sm" variant={electionStatus === 'LIVE' ? 'primary' : 'secondary'} onClick={() => setElectionStatus('LIVE')}>Live</Button>
              <Button size="sm" variant={electionStatus === 'POST_ELECTION' ? 'primary' : 'secondary'} onClick={() => setElectionStatus('POST_ELECTION')}>Post</Button>
          </div>
      </div>
  );

  const renderResultsPage = () => {
    switch (electionStatus) {
        case 'LIVE':
            return <LiveResultsPage positions={positions} setPage={setCurrentPage} />;
        case 'POST_ELECTION':
            return <OfficialResultsPage positions={positions} setPage={setCurrentPage} />;
        case 'PRE_ELECTION':
            return (
                <div className="min-h-[60vh] flex items-center justify-center py-12 px-4">
                    <Card className="max-w-2xl mx-auto p-12 text-center">
                        <h2 className="text-3xl font-bold text-dmi-blue-900">The Election Has Not Started</h2>
                        <p className="text-gray-600 mt-4">The voting period has not yet begun. Please check back on the official start date. Results will be available here once the election is live.</p>
                    </Card>
                </div>
            );
        default:
          return null;
    }
}

  const renderPage = () => {
    switch (currentPage) {
      case Page.Intro:
        return <IntroPage setPage={setCurrentPage} />;
      case Page.Home:
        return <HomePage setPage={setCurrentPage} electionStatus={electionStatus} electionStartDate={electionStartDate} electionEndDate={electionEndDate} />;
      case Page.Authentication:
        return <AuthenticationPage setPage={setCurrentPage} electionStatus={electionStatus} electionStartDate={electionStartDate} electionEndDate={electionEndDate} />;
      case Page.Voting:
        return <VotingPage positions={positions} setPage={setCurrentPage} setVerificationCode={setVerificationCode} isOffline={isOffline} />;
      case Page.VoteSuccess:
        return <VoteSuccessPage verificationCode={verificationCode} setPage={setCurrentPage} />;
      case Page.Verification:
        return <VerificationPage />;
      case Page.Results:
        return renderResultsPage();
      case Page.Winners:
        return <WinnersPage positions={positions} electionStatus={electionStatus} />;
      case Page.Admin:
        if (!currentUser) {
            // Redirect to login if not authenticated
            return <AdminLoginPage onLoginSuccess={handleAdminLogin} adminUsers={adminUsers} />;
        }
        return <AdminDashboard 
                  positions={positions}
                  adminUsers={adminUsers}
                  currentUser={currentUser}
                  setCurrentUser={setCurrentUser}
                  onLogout={handleAdminLogout}
                  onAddPosition={handleAddPosition}
                  onUpdatePosition={handleUpdatePosition}
                  onDeletePosition={handleDeletePosition}
                  onAddCandidate={handleAddCandidate}
                  onUpdateCandidate={handleUpdateCandidate}
                  onDeleteCandidate={handleDeleteCandidate}
                  onAddUser={handleAddUser}
                  onUpdateUser={handleUpdateUser}
                  onDeleteUser={handleDeleteUser}
                  onStartCountdown={handleStartCountdown}
                />;
      default:
        return <HomePage setPage={setCurrentPage} electionStatus={electionStatus} electionStartDate={electionStartDate} electionEndDate={electionEndDate} />;
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 font-sans">
      {currentPage !== Page.Intro && <Header setPage={setCurrentPage} isOffline={isOffline} />}
      <main className="flex-grow">
        {renderPage()}
      </main>
      {currentPage !== Page.Intro && <Footer />}
      {currentPage !== Page.Intro && <ElectionStatusSimulator />}
    </div>
  );
};

export default App;