
import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import { Position, Page } from '../types';
import { MOCK_ADMIN_STATS } from '../constants';
import Card from '../components/Card';
import Button from '../components/Button';

interface LiveResultsPageProps {
  positions: Position[];
  setPage: (page: Page) => void;
}

const StatusIndicator = ({ status }: { status: string }) => (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
        status === 'Online' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
    }`}>
        <svg className={`-ml-0.5 mr-1.5 h-2 w-2 ${status === 'Online' ? 'text-green-400' : 'text-red-400'}`} fill="currentColor" viewBox="0 0 8 8">
            <circle cx="4" cy="4" r="3" />
        </svg>
        {status}
    </span>
);

const LiveIndicator = () => (
    <span className="relative flex h-3 w-3 ml-2">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
        <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
    </span>
);


const LiveResultsPage: React.FC<LiveResultsPageProps> = ({ positions, setPage }) => {
    const [liveStats, setLiveStats] = useState(() => JSON.parse(JSON.stringify(MOCK_ADMIN_STATS)));

    useEffect(() => {
        const interval = setInterval(() => {
            setLiveStats(prevStats => {
                const newStats = { ...prevStats };
                
                // Simulate a small number of new votes
                const newVotes = Math.floor(Math.random() * 5) + 1;
                newStats.votesCast += newVotes;
                
                // Recalculate turnout percentage
                newStats.turnout = parseFloat(((newStats.votesCast / newStats.totalRegistered) * 100).toFixed(1));
                
                // Update a random polling station's vote count
                const stationIndex = Math.floor(Math.random() * newStats.stationStatus.length);
                const updatedStationStatus = [...newStats.stationStatus];
                updatedStationStatus[stationIndex] = {
                    ...updatedStationStatus[stationIndex],
                    votes: updatedStationStatus[stationIndex].votes + newVotes
                };
                newStats.stationStatus = updatedStationStatus;

                // Update the latest hour's turnout data
                if (newStats.hourlyTurnout.length > 0) {
                    const lastHourIndex = newStats.hourlyTurnout.length - 1;
                    const updatedHourlyTurnout = [...newStats.hourlyTurnout];
                    updatedHourlyTurnout[lastHourIndex] = {
                        ...updatedHourlyTurnout[lastHourIndex],
                        votes: updatedHourlyTurnout[lastHourIndex].votes + newVotes
                    };
                    newStats.hourlyTurnout = updatedHourlyTurnout;
                }

                return newStats;
            });
        }, 2500); // Update every 2.5 seconds

        return () => clearInterval(interval);
    }, []);

    return (
        <div className="container mx-auto px-4 py-8">
            <div className="text-center mb-10">
                <div className="flex justify-center items-center">
                    <h1 className="text-4xl font-extrabold text-dmi-blue-900">Live Election Tracker</h1>
                    <LiveIndicator />
                </div>
                <p className="text-lg text-gray-600 mt-2">The election is currently in progress. Watch the numbers update in real-time!</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
                <Card className="p-6 text-center">
                    <h3 className="text-lg font-semibold text-gray-500">Live Votes Cast</h3>
                    <p className="text-5xl font-bold text-dmi-blue-800 transition-all duration-300">{liveStats.votesCast}</p>
                </Card>
                <Card className="p-6 text-center">
                    <h3 className="text-lg font-semibold text-gray-500">Registered Voters</h3>
                    <p className="text-5xl font-bold text-dmi-blue-800">{liveStats.totalRegistered}</p>
                </Card>
                <Card className="p-6 text-center">
                    <h3 className="text-lg font-semibold text-gray-500">Live Voter Turnout</h3>
                    <p className="text-5xl font-bold text-dmi-blue-800 transition-all duration-300">{liveStats.turnout}%</p>
                </Card>
            </div>

            <div className="mb-10">
                <h2 className="text-3xl font-bold text-dmi-blue-900 text-center mb-6">Live Statistics</h2>
                <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                    <Card className="lg:col-span-3 p-6">
                        <h3 className="text-xl font-bold text-dmi-blue-900 mb-4">Turnout by Hour</h3>
                        <div className="h-80">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={liveStats.hourlyTurnout} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis dataKey="hour" />
                                    <YAxis />
                                    <Tooltip />
                                    <Legend />
                                    <Bar dataKey="votes" fill="#1b66c4" name="Votes Cast" />
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </Card>
                    <Card className="lg:col-span-2 p-6">
                        <h3 className="text-xl font-bold text-dmi-blue-900 mb-4">Polling Station Status</h3>
                        <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                <tr>
                                    <th className="px-4 py-2">Station</th>
                                    <th className="px-4 py-2">Votes</th>
                                    <th className="px-4 py-2">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {liveStats.stationStatus.map(s => (
                                    <tr key={s.name} className="border-b">
                                        <td className="px-4 py-3 font-medium">{s.name}</td>
                                        <td className="px-4 py-3">{s.votes}</td>
                                        <td className="px-4 py-3"><StatusIndicator status={s.status} /></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        </div>
                    </Card>
                </div>
            </div>

             <Card className="p-8 mt-10 text-center bg-dmi-blue-50">
                <h2 className="text-2xl font-bold text-dmi-blue-900">Curious about who's leading?</h2>
                <p className="text-gray-600 mt-2 mb-6">While the official results are not in, you can see a fun live animation of potential winners!</p>
                <Button size="lg" onClick={() => setPage(Page.Winners)}>
                    Awine ndindani? (Who is the winner?)
                </Button>
            </Card>
        </div>
    );
};

export default LiveResultsPage;
