import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { MOCK_OVERALL_STATS } from '../constants';
import Card from '../components/Card';
import Button from '../components/Button';
import { Position, Page } from '../types';

interface OfficialResultsPageProps {
  positions: Position[];
  setPage: (page: Page) => void;
}

const OfficialResultsPage: React.FC<OfficialResultsPageProps> = ({ positions, setPage }) => {
  const { totalVotesCast, totalVoters, voterTurnout } = MOCK_OVERALL_STATS;
  
  const statsMap = new Map(MOCK_OVERALL_STATS.positionsWithStats.map(p => [p.positionName, p]));

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-extrabold text-dmi-blue-900">Official Election Results</h1>
        <p className="text-lg text-gray-600 mt-2">SJBU Student Elections 2025</p>
      </div>
      
      <Card className="p-8 text-center bg-gradient-to-r from-dmi-blue-700 to-dmi-blue-800 text-white rounded-xl shadow-lg mb-10">
        <h2 className="text-3xl font-bold">The votes are in!</h2>
        <p className="mt-2 mb-6 text-dmi-blue-100">The election has concluded. See the official winners and celebrate our new student leaders.</p>
        <Button size="lg" variant="secondary" onClick={() => setPage(Page.Winners)}>
          Announce the Winners!
        </Button>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <Card className="p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-500">Total Votes Cast</h3>
          <p className="text-5xl font-bold text-dmi-blue-800">{totalVotesCast}</p>
        </Card>
        <Card className="p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-500">Registered Voters</h3>
          <p className="text-5xl font-bold text-dmi-blue-800">{totalVoters}</p>
        </Card>
        <Card className="p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-500">Voter Turnout</h3>
          <p className="text-5xl font-bold text-dmi-blue-800">{voterTurnout}%</p>
        </Card>
      </div>

      <div className="space-y-8">
        {positions.map((position) => {
          const resultData = statsMap.get(position.name);

          if (!resultData) {
            return (
              <Card key={position.id}>
                <div className="p-6 border-b">
                  <h2 className="text-2xl font-bold text-dmi-blue-900">{position.name}</h2>
                </div>
                <div className="p-6">
                  <p className="text-gray-500">Results for this new position are not yet available.</p>
                  <h4 className="font-semibold mt-4">Registered Candidates:</h4>
                  {position.candidates.length > 0 ? (
                    <ul className="list-disc list-inside mt-2 text-gray-600">
                      {position.candidates.map(c => <li key={c.id}>{c.name}</li>)}
                    </ul>
                  ) : <p className="text-gray-500 mt-2 italic">No candidates are registered for this position.</p>}
                </div>
              </Card>
            );
          }

          return (
            <Card key={resultData.positionName}>
              <div className="p-6 border-b">
                <h2 className="text-2xl font-bold text-dmi-blue-900">{resultData.positionName}</h2>
                <p className="text-sm text-gray-500">{resultData.totalVotes} valid votes</p>
              </div>
              <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-6 items-center">
                <div className="space-y-4">
                  {[...resultData.candidates].sort((a,b) => b.voteCount - a.voteCount).map((candidate) => (
                    <div key={candidate.candidateName} className="p-3 rounded-lg">
                      <div className="flex justify-between items-center mb-1">
                        <p className="font-semibold text-gray-700">
                          {candidate.candidateName}
                        </p>
                        <p className="font-bold text-gray-600">
                          {candidate.voteCount} votes ({candidate.votePercentage}%)
                        </p>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div
                          className="h-2.5 rounded-full bg-dmi-blue-600"
                          style={{ width: `${candidate.votePercentage}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={resultData.candidates} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                      <XAxis type="number" hide />
                      <YAxis type="category" dataKey="candidateName" width={80} tick={{fontSize: 12}} />
                      <Tooltip formatter={(value: number) => [`${value} votes`, "Votes"]} />
                      <Bar dataKey="voteCount" barSize={20} fill="#1b66c4" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </Card>
          );
        })}
      </div>
      
      <div className="mt-12 text-center">
        <h3 className="text-xl font-bold text-dmi-blue-900">Download Reports</h3>
        <p className="text-gray-600 mt-2 mb-4">Download the full election report for auditing and transparency.</p>
        <div className="flex justify-center space-x-4">
            <Button variant="secondary">Download Full Report (PDF)</Button>
            <Button variant="secondary">Download Raw Data (CSV)</Button>
        </div>
      </div>
    </div>
  );
};

export default OfficialResultsPage;