
import React, { useState, useEffect } from 'react';
import { Page, VoteSelection, Candidate, Position } from '../types';
import Button from '../components/Button';
import Card from '../components/Card';
import Modal from '../components/Modal';

interface VotingPageProps {
  positions: Position[];
  setPage: (page: Page) => void;
  setVerificationCode: (code: string) => void;
  isOffline: boolean;
}

const VotingPage: React.FC<VotingPageProps> = ({ positions, setPage, setVerificationCode, isOffline }) => {
  const [currentPositionIndex, setCurrentPositionIndex] = useState(0);
  const [selections, setSelections] = useState<VoteSelection>({});
  const [view, setView] = useState<'voting' | 'review'>('voting');
  
  const [isManifestoModalOpen, setIsManifestoModalOpen] = useState(false);
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [modalCandidate, setModalCandidate] = useState<Candidate | null>(null);

  // Effect to load selections from localStorage on mount
  useEffect(() => {
    try {
      const savedSelections = localStorage.getItem('dmi-vote-selections');
      if (savedSelections) {
        setSelections(JSON.parse(savedSelections));
      }
    } catch (error) {
      console.error("Could not load selections from local storage", error);
    }
  }, []);

  // Effect to save selections to localStorage whenever they change
  useEffect(() => {
    if (Object.keys(selections).length > 0) {
      try {
        localStorage.setItem('dmi-vote-selections', JSON.stringify(selections));
      } catch (error) {
        console.error("Could not save selections to local storage", error);
      }
    }
  }, [selections]);


  const currentPosition = positions[currentPositionIndex];

  const handleSelect = (candidateId: string | 'abstain') => {
    setSelections({
      ...selections,
      [currentPosition.id]: candidateId,
    });
  };

  const handleNext = () => {
    if (currentPositionIndex < positions.length - 1) {
      setCurrentPositionIndex(currentPositionIndex + 1);
    } else {
      setView('review');
    }
  };

  const handleBack = () => {
    if (currentPositionIndex > 0) {
      setCurrentPositionIndex(currentPositionIndex - 1);
    }
  };
  
  const handleSubmit = () => {
      if (isOffline) {
        alert("You are offline. Please reconnect to the internet to submit your vote.");
        return;
      }
      // In a real app, this would be an API call
      const generatedCode = `SJBU-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
      setVerificationCode(generatedCode);
      setIsConfirmModalOpen(false);
      setPage(Page.VoteSuccess);

      // Clear local storage on successful submission
      try {
          localStorage.removeItem('dmi-vote-selections');
      } catch (error) {
          console.error("Could not clear selections from local storage", error);
      }
  }
  
  const openManifesto = (candidate: Candidate) => {
    setModalCandidate(candidate);
    setIsManifestoModalOpen(true);
  };
  
  if (!currentPosition) {
    return (
        <div className="container mx-auto px-4 py-8 text-center">
            <Card className="max-w-4xl mx-auto p-8">
                <h2 className="text-2xl font-bold text-dmi-blue-900">Election Not Configured</h2>
                <p className="text-gray-600 mt-4">There are no positions or candidates configured for this election yet. Please check back later or contact an administrator.</p>
            </Card>
        </div>
    );
  }

  const renderVotingView = () => (
    <Card className="max-w-4xl mx-auto">
      <div className="p-6 border-b">
        <p className="text-sm text-gray-500">Position {currentPositionIndex + 1} of {positions.length}</p>
        <h2 className="text-2xl font-bold text-dmi-blue-900">{currentPosition.name}</h2>
        <div className="w-full bg-gray-200 rounded-full h-2.5 mt-3">
            <div className="bg-dmi-blue-600 h-2.5 rounded-full" style={{ width: `${((currentPositionIndex + 1) / positions.length) * 100}%` }}></div>
        </div>
      </div>
      <div className="p-6 space-y-4">
        {currentPosition.candidates.map((candidate) => (
          <div
            key={candidate.id}
            className={`p-4 border rounded-lg cursor-pointer transition-all ${selections[currentPosition.id] === candidate.id ? 'bg-dmi-blue-50 border-dmi-blue-500 ring-2 ring-dmi-blue-500' : 'hover:bg-gray-50'}`}
            onClick={() => handleSelect(candidate.id)}
          >
            <div className="flex items-center space-x-4">
              <img src={candidate.photoUrl} alt={candidate.name} className="w-16 h-16 rounded-full object-cover" />
              <div className="flex-grow">
                <h4 className="text-lg font-semibold text-dmi-blue-900">{candidate.name}</h4>
                <p className="text-sm text-gray-500">{candidate.faculty}</p>
                 <Button variant="secondary" size="sm" className="mt-1" onClick={(e) => { e.stopPropagation(); openManifesto(candidate); }}>View Manifesto</Button>
              </div>
              <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${selections[currentPosition.id] === candidate.id ? 'bg-dmi-blue-600 border-dmi-blue-600' : 'border-gray-300'}`}>
                {selections[currentPosition.id] === candidate.id && <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>}
              </div>
            </div>
          </div>
        ))}
        <div
          className={`p-4 border rounded-lg cursor-pointer transition-all ${selections[currentPosition.id] === 'abstain' ? 'bg-dmi-blue-50 border-dmi-blue-500 ring-2 ring-dmi-blue-500' : 'hover:bg-gray-50'}`}
          onClick={() => handleSelect('abstain')}
        >
          <div className="flex items-center space-x-4">
              <div className="w-16 h-16 rounded-full bg-gray-200 flex items-center justify-center">
                  <svg className="w-8 h-8 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"></path></svg>
              </div>
             <div className="flex-grow">
                 <h4 className="text-lg font-semibold text-gray-800">Abstain</h4>
                 <p className="text-sm text-gray-500">I do not wish to vote for this position.</p>
             </div>
             <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${selections[currentPosition.id] === 'abstain' ? 'bg-dmi-blue-600 border-dmi-blue-600' : 'border-gray-300'}`}>
                {selections[currentPosition.id] === 'abstain' && <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>}
              </div>
          </div>
        </div>
      </div>
       <div className="p-6 bg-gray-50 flex justify-between items-center">
        <Button variant="secondary" onClick={handleBack} disabled={currentPositionIndex === 0}>Back</Button>
        <Button onClick={handleNext} disabled={!selections[currentPosition.id]}>
          {currentPositionIndex < positions.length - 1 ? 'Next Position' : 'Review Ballot'}
        </Button>
      </div>
    </Card>
  );

  const renderReviewView = () => (
      <Card className="max-w-4xl mx-auto">
          <div className="p-6 border-b text-center">
              <h2 className="text-3xl font-bold text-dmi-blue-900">Review Your Ballot</h2>
              <p className="text-gray-600 mt-2">Please carefully review your selections. Once submitted, votes CANNOT be changed.</p>
          </div>
          <div className="p-6 space-y-4">
              {positions.map((position, index) => {
                  const selectionId = selections[position.id];
                  const selectionName = selectionId === 'abstain' ? 'Abstain' : position.candidates.find(c => c.id === selectionId)?.name || 'Not Voted';
                  return (
                      <div key={position.id} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                          <div>
                              <p className="font-semibold text-dmi-blue-800">{position.name}</p>
                              <p className={`text-lg font-medium ${selectionName === 'Abstain' || selectionName === 'Not Voted' ? 'text-gray-700 italic' : 'text-dmi-blue-900'}`}>{selectionName}</p>
                          </div>
                          <Button variant="secondary" size="sm" onClick={() => { setCurrentPositionIndex(index); setView('voting'); }}>Change</Button>
                      </div>
                  );
              })}
          </div>
          <div className="p-6 bg-gray-50 flex justify-between items-center">
             <Button variant="secondary" onClick={() => setView('voting')}>Go Back to Ballot</Button>
             <Button onClick={() => setIsConfirmModalOpen(true)}>Submit Ballot</Button>
          </div>
      </Card>
  );

  return (
    <>
      {isOffline && (
        <div className="fixed top-0 left-0 right-0 bg-yellow-500 text-center text-white p-2 z-50 shadow-lg" role="alert">
            <div className="container mx-auto flex items-center justify-center">
                 <svg className="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.364 5.636a9 9 0 010 12.728m-12.728 0a9 9 0 010-12.728m12.728 0L5.636 18.364m12.728-12.728L5.636 5.636"></path></svg>
                <span className="font-semibold">You are currently offline. Your progress is saved on this device. Please reconnect to submit your ballot.</span>
            </div>
        </div>
      )}
      <div className={`container mx-auto px-4 py-8 transition-all ${isOffline ? 'pt-20' : ''}`}>
          {view === 'voting' && renderVotingView()}
          {view === 'review' && renderReviewView()}
          
          <Modal 
              isOpen={isManifestoModalOpen} 
              onClose={() => setIsManifestoModalOpen(false)}
              title={`Manifesto: ${modalCandidate?.name || ''}`}
          >
              <p className="text-gray-600 whitespace-pre-wrap">{modalCandidate?.manifesto}</p>
          </Modal>

          <Modal
              isOpen={isConfirmModalOpen}
              onClose={() => setIsConfirmModalOpen(false)}
              title="Final Confirmation"
          >
              <div className="text-center">
                  <svg className="w-16 h-16 text-red-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                  <p className="text-lg text-gray-600 my-4">Are you sure you want to submit your ballot? This action is final and irreversible.</p>
                  {isOffline && <p className="text-yellow-600 mt-2 p-2 bg-yellow-100 rounded-md font-semibold">You are currently offline. Please reconnect to the internet to submit your vote.</p>}
                  <div className="flex justify-center space-x-4 mt-6">
                      <Button variant="secondary" onClick={() => setIsConfirmModalOpen(false)}>No, Go Back</Button>
                      <Button variant="danger" onClick={handleSubmit} disabled={isOffline}>Yes, Submit Now</Button>
                  </div>
              </div>
          </Modal>
      </div>
    </>
  );
};

export default VotingPage;