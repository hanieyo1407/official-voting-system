
import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import { MOCK_ADMIN_STATS } from '../constants';
import { Position, Candidate, AdminUser, AuditLogEntry, AdminRole } from '../types';
import { usePermissions, Permissions } from '../hooks/usePermissions';
import Card from '../components/Card';
import Button from '../components/Button';
import Modal from '../components/Modal';
import ImageUploader from '../components/ImageUploader';

// --- Helper Icons ---
const PlusIcon = () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg>;
const EditIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z"></path></svg>;
const TrashIcon = () => <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>;
const UserIcon = () => <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>;
const LogoutIcon = () => <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>;
const DashboardIcon = () => <svg className="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>;
const PositionsIcon = () => <svg className="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path></svg>;
const CandidatesIcon = () => <svg className="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>;
const UsersIcon = () => <svg className="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21v-2a4 4 0 00-4-4H9a4 4 0 00-4 4v2"></path></svg>;
const AuditIcon = () => <svg className="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>;
const SettingsIcon = () => <svg className="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066 2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.096 2.572-1.065z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>;


// --- Type Definitions ---
interface AdminDashboardProps {
    positions: Position[];
    adminUsers: AdminUser[];
    currentUser: AdminUser;
    setCurrentUser: (user: AdminUser) => void;
    onLogout: () => void;
    onAddPosition: (position: Omit<Position, 'id' | 'candidates'>) => void;
    onUpdatePosition: (position: Position) => void;
    onDeletePosition: (positionId: string) => void;
    onAddCandidate: (positionId: string, candidate: Omit<Candidate, 'id'>) => void;
    onUpdateCandidate: (positionId: string, candidate: Candidate) => void;
    onDeleteCandidate: (positionId: string, candidateId: string) => void;
    onAddUser: (user: Omit<AdminUser, 'id'>) => void;
    onUpdateUser: (user: AdminUser) => void;
    onDeleteUser: (userId: string) => void;
    onStartCountdown: (hours: number) => void;
}

type AdminView = 'dashboard' | 'positions' | 'candidates' | 'users' | 'audit' | 'settings';
type ModalType = 'ADD_POSITION' | 'EDIT_POSITION' | 'DELETE_POSITION' | 'ADD_CANDIDATE' | 'EDIT_CANDIDATE' | 'DELETE_CANDIDATE' | 'ADD_USER' | 'EDIT_USER' | 'DELETE_USER';
interface ModalState {
    isOpen: boolean;
    type: ModalType | null;
    data?: any;
}

// --- Role Switcher Component for Demo ---
const RoleSwitcher: React.FC<{ adminUsers: AdminUser[], currentUser: AdminUser, setCurrentUser: (user: AdminUser) => void, onLogout: () => void }> = ({ adminUsers, currentUser, setCurrentUser, onLogout }) => {
    return (
        <Card className="mb-6 p-4">
            <div className="flex flex-col sm:flex-row items-center justify-between">
                <div className="flex items-center mb-4 sm:mb-0">
                    <UserIcon />
                    <span className="font-semibold text-dmi-blue-900">Current User:</span>
                     <span className="ml-2 mr-2 px-3 py-1 text-sm font-semibold text-dmi-blue-800 bg-dmi-blue-100 rounded-full">{currentUser.username}</span>
                    <span className="px-3 py-1 text-sm font-bold text-white bg-dmi-blue-700 rounded-full">{currentUser.role.replace('_', ' ')}</span>
                </div>
                <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-600 hidden md:inline">Switch Role (Demo):</span>
                    {adminUsers.map(user => (
                        <Button
                            key={user.id}
                            size="sm"
                            variant={currentUser.id === user.id ? 'primary' : 'secondary'}
                            onClick={() => setCurrentUser(user)}
                             className="hidden md:flex"
                        >
                            {user.role}
                        </Button>
                    ))}
                    <Button size="sm" variant="secondary" onClick={onLogout}><LogoutIcon/> Logout</Button>
                </div>
            </div>
        </Card>
    );
};

// --- Sidebar Navigation ---
interface SidebarProps {
    activeView: AdminView;
    setActiveView: (view: AdminView) => void;
    permissions: Permissions;
}
const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView, permissions }) => {
    const navItems = [
        { id: 'dashboard', label: 'Dashboard', icon: <DashboardIcon />, permitted: permissions.canViewDashboard },
        { id: 'positions', label: 'Positions', icon: <PositionsIcon />, permitted: permissions.canViewPositions },
        { id: 'candidates', label: 'Candidates', icon: <CandidatesIcon />, permitted: permissions.canViewCandidates },
        { id: 'users', label: 'User Management', icon: <UsersIcon />, permitted: permissions.canViewUsers },
        { id: 'audit', label: 'Audit Log', icon: <AuditIcon />, permitted: permissions.canViewAuditLog },
        { id: 'settings', label: 'Settings', icon: <SettingsIcon />, permitted: permissions.canEditSettings },
    ];

    return (
        <aside className="bg-white p-4 rounded-xl shadow-md">
            <nav className="space-y-2">
                {navItems.map(item => {
                    if (!item.permitted) return null;
                    const isActive = activeView === item.id;
                    return (
                        <button
                            key={item.id}
                            onClick={() => setActiveView(item.id as AdminView)}
                            className={`w-full flex items-center p-3 text-left rounded-lg transition-colors ${isActive ? 'bg-dmi-blue-600 text-white font-bold shadow' : 'text-gray-700 hover:bg-dmi-blue-50 hover:text-dmi-blue-800'}`}
                        >
                            {item.icon}
                            <span>{item.label}</span>
                        </button>
                    )
                })}
            </nav>
        </aside>
    );
};


// --- Admin Dashboard Component ---
const AdminDashboard: React.FC<AdminDashboardProps> = (props) => {
    const { currentUser } = props;
    const [activeView, setActiveView] = useState<AdminView>('dashboard');
    const [modal, setModal] = useState<ModalState>({ isOpen: false, type: null });
    const permissions = usePermissions(currentUser);

    const handleOpenModal = (type: ModalType, data?: any) => setModal({ isOpen: true, type, data });
    const handleCloseModal = () => setModal({ isOpen: false, type: null });
    
    // Effect to handle view changes when role changes
    useEffect(() => {
        const viewPermissions: { [key in AdminView]: keyof Permissions } = {
            dashboard: 'canViewDashboard',
            positions: 'canViewPositions',
            candidates: 'canViewCandidates',
            users: 'canViewUsers',
            audit: 'canViewAuditLog',
            settings: 'canEditSettings',
        };

        if (!permissions[viewPermissions[activeView]]) {
            setActiveView('dashboard');
        }
    }, [currentUser, activeView, permissions]);

    const renderActiveView = () => {
        switch (activeView) {
            case 'dashboard': return <DashboardView />;
            case 'positions': return <PositionsView {...props} permissions={permissions} onOpenModal={handleOpenModal} />;
            case 'candidates': return <CandidatesView {...props} permissions={permissions} onOpenModal={handleOpenModal} />;
            case 'users': return <UserManagementView {...props} permissions={permissions} onOpenModal={handleOpenModal} />;
            case 'audit': return <AuditLogView />;
            case 'settings': return <SettingsView permissions={permissions} onStartCountdown={props.onStartCountdown} />;
            default: return <DashboardView />;
        }
    }

    return (
        <div className="container mx-auto px-4 py-8">
            <h1 className="text-3xl font-bold text-dmi-blue-900 mb-6">Administrator Dashboard</h1>
            
            <RoleSwitcher adminUsers={props.adminUsers} currentUser={props.currentUser} setCurrentUser={props.setCurrentUser} onLogout={props.onLogout}/>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                <div className="lg:col-span-1">
                   <Sidebar activeView={activeView} setActiveView={setActiveView} permissions={permissions} />
                </div>
                <div className="lg:col-span-3">
                   {renderActiveView()}
                </div>
            </div>
        
            <ManagementModals modalState={modal} onClose={handleCloseModal} permissions={permissions} {...props} />
        </div>
    );
};

// --- Dashboard View ---
const DashboardView: React.FC = () => {
    const { votesCast, turnout, stationStatus, hourlyTurnout } = MOCK_ADMIN_STATS;
    
    const StatusIndicator = ({ status }: { status: string }) => (
        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${ status === 'Online' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' }`}>{status}</span>
    );
    
    return (
        <div className="space-y-8">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="p-6">
                    <h3 className="text-gray-500 font-semibold">Total Votes Cast</h3>
                    <p className="text-4xl font-bold text-dmi-blue-800 mt-2">{votesCast}</p>
                </Card>
                 <Card className="p-6">
                    <h3 className="text-gray-500 font-semibold">Voter Turnout</h3>
                    <p className="text-4xl font-bold text-dmi-blue-800 mt-2">{turnout}%</p>
                </Card>
            </div>

            <Card className="p-6">
                <h2 className="text-xl font-bold text-dmi-blue-900 mb-4">Turnout by Hour</h2>
                <div className="h-80">
                     <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={hourlyTurnout} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="hour" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Bar dataKey="votes" fill="#1b66c4" name="Votes Cast" />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </Card>

            <Card className="p-6">
                <h2 className="text-xl font-bold text-dmi-blue-900 mb-4">Polling Station Status</h2>
                 <table className="w-full text-left text-sm">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                        <tr><th className="px-4 py-2">Station</th><th className="px-4 py-2">Votes</th><th className="px-4 py-2">Status</th></tr>
                    </thead>
                    <tbody>
                        {stationStatus.map(s => <tr key={s.name} className="border-b"><td className="px-4 py-3 font-medium">{s.name}</td><td className="px-4 py-3">{s.votes}</td><td className="px-4 py-3"><StatusIndicator status={s.status} /></td></tr>)}
                    </tbody>
                </table>
            </Card>
        </div>
    );
};

// --- Settings View ---
interface SettingsViewProps {
    permissions: Permissions;
    onStartCountdown: (hours: number) => void;
}
const SettingsView: React.FC<SettingsViewProps> = ({ permissions, onStartCountdown }) => {
    const [countdownHours, setCountdownHours] = useState('48');

    const handleStartCountdown = (e: React.FormEvent) => {
        e.preventDefault();
        const hours = parseInt(countdownHours, 10);
        if (hours > 0 && hours <= 48) {
            onStartCountdown(hours);
            alert(`Countdown successfully started for ${hours} hours! The home page timer will now reflect this change.`);
        } else {
            alert('Please enter a valid number of hours between 1 and 48.');
        }
    };

    return (
        <Card>
            <div className="p-6 border-b">
                <h2 className="text-xl font-bold text-dmi-blue-900">Election Settings</h2>
                <p className="text-sm text-gray-500">Configure core parameters for the election.</p>
            </div>
            <form className="p-6 space-y-6">
                {!permissions.canEditSettings && (
                    <div className="bg-dmi-blue-50 text-dmi-blue-800 p-3 rounded-lg text-sm">
                        Settings can only be modified by a Super Admin.
                    </div>
                )}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label htmlFor="start-date" className="block text-sm font-medium text-gray-700">Election Start Date</label>
                        <input type="datetime-local" id="start-date" name="start-date" disabled={!permissions.canEditSettings} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-dmi-blue-500 focus:ring-dmi-blue-500 disabled:bg-gray-100" />
                    </div>
                     <div>
                        <label htmlFor="end-date" className="block text-sm font-medium text-gray-700">Election End Date</label>
                        <input type="datetime-local" id="end-date" name="end-date" disabled={!permissions.canEditSettings} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-dmi-blue-500 focus:ring-dmi-blue-500 disabled:bg-gray-100" />
                    </div>
                </div>
                 <div>
                    <label htmlFor="voucher-rules" className="block text-sm font-medium text-gray-700">Voucher Generation Rules</label>
                     <textarea id="voucher-rules" name="voucher-rules" rows={4} disabled={!permissions.canEditSettings} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-dmi-blue-500 focus:ring-dmi-blue-500 disabled:bg-gray-100" placeholder="e.g., Alphanumeric, 12 characters, expires in 24 hours..."></textarea>
                </div>
                 <div className="pt-4 flex justify-end">
                    <Button type="submit" disabled={!permissions.canEditSettings} disabledTooltip="Requires Super Admin role.">Save Settings</Button>
                </div>
            </form>

            <div className="p-6 border-t space-y-4">
                <h3 className="text-lg font-bold text-dmi-blue-800">Start Election Countdown</h3>
                <p className="text-sm text-gray-600">
                    This will immediately set the election start time based on the hours provided from now. This action is irreversible for this session.
                </p>
                <form onSubmit={handleStartCountdown} className="flex flex-col sm:flex-row sm:items-end sm:space-x-4">
                    <div className="flex-grow">
                        <label htmlFor="countdown-hours" className="block text-sm font-medium text-gray-700">Countdown Duration (1-48 Hours)</label>
                        <input
                            type="number"
                            id="countdown-hours"
                            name="countdown-hours"
                            value={countdownHours}
                            onChange={e => setCountdownHours(e.target.value)}
                            min="1"
                            max="48"
                            disabled={!permissions.canEditSettings}
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-dmi-blue-500 focus:ring-dmi-blue-500 disabled:bg-gray-100"
                            required
                        />
                    </div>
                    <div className="mt-4 sm:mt-0">
                        <Button
                            type="submit"
                            disabled={!permissions.canEditSettings}
                            disabledTooltip="Requires Super Admin role."
                            variant="danger"
                        >
                            Start Countdown
                        </Button>
                    </div>
                </form>
            </div>
        </Card>
    );
};

// --- Audit Log View ---
const AuditLogView: React.FC = () => {
    const [logs] = useState<AuditLogEntry[]>([]); // Assuming MOCK_AUDIT_LOG_DATA is not available, provide default empty array
    const [searchTerm, setSearchTerm] = useState('');

    const filteredLogs = logs.filter(log =>
        log.adminUsername.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.details.toLowerCase().includes(searchTerm.toLowerCase())
    ).sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

    const getActionChipColor = (action: string) => {
        if (action.includes('SUCCESS') || action.includes('CREATED')) return 'bg-green-100 text-green-800';
        if (action.includes('FAILED') || action.includes('DELETED')) return 'bg-red-100 text-red-800';
        if (action.includes('UPDATED') || action.includes('CHANGED')) return 'bg-yellow-100 text-yellow-800';
        return 'bg-gray-100 text-gray-800';
    };

    return (
        <Card>
            <div className="p-4 border-b">
                <h2 className="text-xl font-bold text-dmi-blue-900">Admin Audit Log</h2>
                <p className="text-sm text-gray-500">Track all administrative actions performed on the system.</p>
            </div>
            <div className="p-4">
                <input
                    type="text"
                    placeholder="Search logs by user, action, or details..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-lg focus:ring-dmi-blue-500 focus:border-dmi-blue-500"
                    aria-label="Search audit logs"
                />
            </div>
            <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                    <thead className="bg-gray-50 text-xs text-gray-700 uppercase">
                        <tr>
                            <th scope="col" className="px-4 py-3">Timestamp</th>
                            <th scope="col" className="px-4 py-3">Admin User</th>
                            <th scope="col" className="px-4 py-3">Action</th>
                            <th scope="col" className="px-4 py-3">Details</th>
                            <th scope="col" className="px-4 py-3">IP Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredLogs.map(log => (
                            <tr key={log.id} className="border-b hover:bg-gray-50">
                                <td className="px-4 py-3 text-gray-600 whitespace-nowrap">
                                    {log.timestamp.toLocaleString()}
                                </td>
                                <td className="px-4 py-3 font-medium text-dmi-blue-800">{log.adminUsername}</td>
                                <td className="px-4 py-3">
                                    <span className={`px-2 py-1 font-semibold rounded-full text-xs ${getActionChipColor(log.action)}`}>
                                        {log.action.replace('_', ' ')}
                                    </span>
                                </td>
                                <td className="px-4 py-3 text-gray-700">{log.details}</td>
                                <td className="px-4 py-3 font-mono text-gray-500">{log.ipAddress}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {filteredLogs.length === 0 && (
                    <div className="text-center p-8 text-gray-500">
                        <p>No audit logs found matching your search criteria.</p>
                    </div>
                )}
            </div>
        </Card>
    );
};

// --- Positions Management View ---
interface PositionsViewProps extends Pick<AdminDashboardProps, 'positions'> {
    permissions: Permissions;
    onOpenModal: (type: ModalType, data?: any) => void;
}
const PositionsView: React.FC<PositionsViewProps> = ({ positions, permissions, onOpenModal }) => {
    return (
    <Card>
        <div className="p-4 flex justify-between items-center border-b">
             <h2 className="text-xl font-bold text-dmi-blue-900">Manage Positions</h2>
            <Button 
                onClick={() => onOpenModal('ADD_POSITION')}
                disabled={!permissions.canManagePositions}
                disabledTooltip="Requires Admin or Super Admin role."
            >
                <PlusIcon/> Add Position
            </Button>
        </div>
        <table className="w-full text-left">
            <thead className="bg-gray-50">
                <tr>
                    <th className="p-4 text-sm font-semibold text-gray-600">Position Name</th>
                    <th className="p-4 text-sm font-semibold text-gray-600">Candidates</th>
                    <th className="p-4 text-sm font-semibold text-gray-600">Actions</th>
                </tr>
            </thead>
            <tbody>
                {positions.map(pos => (
                    <tr key={pos.id} className="border-b">
                        <td className="p-4 font-semibold text-dmi-blue-800">{pos.name}</td>
                        <td className="p-4">{pos.candidates.length}</td>
                        <td className="p-4">
                            <div className="flex space-x-2">
                                <Button 
                                    size="sm" 
                                    variant="secondary" 
                                    onClick={() => onOpenModal('EDIT_POSITION', pos)}
                                    disabled={!permissions.canManagePositions}
                                    disabledTooltip="Requires Admin or Super Admin role."
                                ><EditIcon/> Edit</Button>
                                <Button 
                                    size="sm" 
                                    variant="danger" 
                                    onClick={() => onOpenModal('DELETE_POSITION', pos)}
                                    disabled={!permissions.canManagePositions}
                                    disabledTooltip="Requires Admin or Super Admin role."
                                ><TrashIcon/> Delete</Button>
                            </div>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    </Card>
    );
};


// --- Candidates Management View ---
interface CandidatesViewProps extends Pick<AdminDashboardProps, 'positions'> {
    permissions: Permissions;
    onOpenModal: (type: ModalType, data?: any) => void;
}
const CandidatesView: React.FC<CandidatesViewProps> = ({ positions, permissions, onOpenModal }) => {
    const [selectedPositionId, setSelectedPositionId] = useState<string | null>(positions[0]?.id || null);
    
    useEffect(() => {
        if (!selectedPositionId && positions.length > 0) {
            setSelectedPositionId(positions[0].id);
        }
         if (positions.length > 0 && !positions.find(p => p.id === selectedPositionId)) {
            setSelectedPositionId(positions[0].id);
        }
        if (positions.length === 0) {
            setSelectedPositionId(null);
        }
    }, [positions, selectedPositionId]);

    const selectedPosition = positions.find(p => p.id === selectedPositionId);

    return (
        <div className="space-y-6">
            <Card className="p-4">
                 <label htmlFor="position-select" className="block text-sm font-medium text-gray-700 mb-2">Select Position to Manage</label>
                 <select 
                    id="position-select"
                    value={selectedPositionId || ''}
                    onChange={(e) => setSelectedPositionId(e.target.value)}
                    className="mt-1 block w-full p-2 rounded-md border-gray-300 shadow-sm focus:border-dmi-blue-500 focus:ring-dmi-blue-500"
                 >
                     {positions.length > 0 ? positions.map(p => (
                         <option key={p.id} value={p.id}>{p.name}</option>
                     )) : <option disabled>No positions available</option>}
                 </select>
            </Card>

            {selectedPosition ? (
                <Card>
                    <div className="p-4 flex justify-between items-center border-b">
                        <h2 className="text-xl font-bold text-dmi-blue-900">Candidates for: <span className="font-normal">{selectedPosition.name}</span></h2>
                        <Button 
                            onClick={() => onOpenModal('ADD_CANDIDATE', selectedPosition)}
                            disabled={!permissions.canManageCandidates}
                            disabledTooltip="Requires Admin or Super Admin role."
                        >
                            <PlusIcon/> Add Candidate
                        </Button>
                    </div>
                    <div className="p-4">
                        {selectedPosition.candidates.length > 0 ? (
                            <div className="space-y-3">
                                {selectedPosition.candidates.map(cand => (
                                    <div key={cand.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border">
                                        <div className="flex items-center space-x-4">
                                            <img src={cand.photoUrl} alt={cand.name} className="w-16 h-16 rounded-full object-cover"/>
                                            <div>
                                                <p className="font-semibold text-gray-800">{cand.name}</p>
                                                <p className="text-sm text-gray-500">{cand.faculty}</p>
                                            </div>
                                        </div>
                                        <div className="flex space-x-2">
                                            <Button size="sm" variant="secondary" onClick={() => onOpenModal('EDIT_CANDIDATE', { ...cand, positionId: selectedPosition.id })}
                                                disabled={!permissions.canManageCandidates}
                                                disabledTooltip="Requires Admin or Super Admin role."
                                            ><EditIcon /></Button>
                                            <Button size="sm" variant="danger" onClick={() => onOpenModal('DELETE_CANDIDATE', { ...cand, positionId: selectedPosition.id })}
                                                 disabled={!permissions.canManageCandidates}
                                                 disabledTooltip="Requires Admin or Super Admin role."
                                            ><TrashIcon /></Button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="text-center py-8">
                                <h3 className="text-lg font-semibold text-gray-700">No Candidates Yet</h3>
                                <p className="text-gray-500 mt-1">{permissions.canManageCandidates ? 'Click "Add Candidate" to get started.' : 'Contact an admin to add candidates.'}</p>
                            </div>
                        )}
                    </div>
                </Card>
            ) : (
                <Card className="flex items-center justify-center h-full p-8">
                     <div className="text-center">
                        <h3 className="text-lg font-semibold text-gray-700">Select a Position</h3>
                        <p className="text-gray-500 mt-1">Choose a position from the dropdown to manage its candidates.</p>
                    </div>
                </Card>
            )}
        </div>
    );
};

// --- User Management View (Super Admin only) ---
interface UserManagementViewProps extends Pick<AdminDashboardProps, 'adminUsers'> {
    permissions: Permissions;
    onOpenModal: (type: ModalType, data?: any) => void;
}
const UserManagementView: React.FC<UserManagementViewProps> = ({ adminUsers, permissions, onOpenModal }) => {
    return (
        <Card>
            <div className="p-4 flex justify-between items-center border-b">
                <h2 className="text-xl font-bold text-dmi-blue-900">Manage Admin Users</h2>
                <Button 
                    disabled={!permissions.canManageUsers}
                    disabledTooltip="Requires Super Admin role."
                    onClick={() => onOpenModal('ADD_USER')}
                >
                    <PlusIcon/> Create New Admin
                </Button>
            </div>
             
            <table className="w-full text-left">
                <thead className="bg-gray-50">
                    <tr>
                        <th className="p-4 text-sm font-semibold text-gray-600">Username</th>
                        <th className="p-4 text-sm font-semibold text-gray-600">Role</th>
                        <th className="p-4 text-sm font-semibold text-gray-600">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {adminUsers.map(user => (
                        <tr key={user.id} className="border-b">
                            <td className="p-4 font-semibold text-dmi-blue-800">{user.username}</td>
                            <td className="p-4">
                                 <span className={`px-2 py-1 text-xs font-semibold rounded-full ${ 
                                     user.role === 'super_admin' ? 'bg-dmi-gold-500 text-white' : 
                                     user.role === 'admin' ? 'bg-dmi-blue-100 text-dmi-blue-800' :
                                     'bg-gray-200 text-gray-800'
                                 }`}>
                                     {user.role}
                                </span>
                            </td>
                            <td className="p-4">
                                <div className="flex space-x-2">
                                    <Button 
                                        size="sm" variant="secondary" 
                                        disabled={!permissions.canManageUsers} 
                                        disabledTooltip="Requires Super Admin role."
                                        onClick={() => onOpenModal('EDIT_USER', user)}
                                    ><EditIcon/> Edit</Button>
                                    <Button 
                                        size="sm" 
                                        variant="danger" 
                                        disabled={!permissions.canManageUsers} 
                                        disabledTooltip="Requires Super Admin role."
                                        onClick={() => onOpenModal('DELETE_USER', user)}
                                    ><TrashIcon/> Delete</Button>
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </Card>
    );
};


// --- Modals and Forms ---
interface ManagementModalsProps extends Omit<AdminDashboardProps, 'currentUser' | 'setCurrentUser' | 'onLogout' | 'onStartCountdown'> {
    modalState: ModalState;
    onClose: () => void;
    permissions: Permissions;
}
const ManagementModals: React.FC<ManagementModalsProps> = ({ modalState, onClose, permissions, ...handlers }) => {
    const { isOpen, type, data } = modalState;

    if (!isOpen) return null;
    
    // Position Modals
    if ((type === 'ADD_POSITION' || type === 'EDIT_POSITION') && permissions.canManagePositions) {
        return (
            <Modal isOpen={isOpen} onClose={onClose} title={type === 'ADD_POSITION' ? 'Add New Position' : 'Edit Position'}>
                <PositionForm
                    position={data}
                    onSave={(posData) => {
                        if (type === 'ADD_POSITION') handlers.onAddPosition(posData);
                        else handlers.onUpdatePosition({ ...data, ...posData });
                        onClose();
                    }}
                    onCancel={onClose}
                />
            </Modal>
        );
    }
    
    // Candidate Modals
    if ((type === 'ADD_CANDIDATE' || type === 'EDIT_CANDIDATE') && permissions.canManageCandidates) {
         return (
            <Modal isOpen={isOpen} onClose={onClose} title={type === 'ADD_CANDIDATE' ? `Add Candidate to ${data.name}` : 'Edit Candidate'}>
                <CandidateForm
                    candidate={type === 'EDIT_CANDIDATE' ? data : undefined}
                    onSave={(candData) => {
                        const positionId = type === 'ADD_CANDIDATE' ? data.id : data.positionId;
                        if (type === 'ADD_CANDIDATE') handlers.onAddCandidate(positionId, candData);
                        else handlers.onUpdateCandidate(positionId, { ...data, ...candData });
                        onClose();
                    }}
                    onCancel={onClose}
                />
            </Modal>
        );
    }

     // User Modals
    if ((type === 'ADD_USER' || type === 'EDIT_USER') && permissions.canManageUsers) {
        return (
            <Modal isOpen={isOpen} onClose={onClose} title={type === 'ADD_USER' ? 'Create New Admin User' : 'Edit Admin User'}>
                <UserForm
                    user={data}
                    onSave={(userData) => {
                        if (type === 'ADD_USER') handlers.onAddUser(userData);
                        else handlers.onUpdateUser({ ...data, ...userData });
                        onClose();
                    }}
                    onCancel={onClose}
                />
            </Modal>
        );
    }


    // Delete Confirmation Modals
    if (
        (type === 'DELETE_POSITION' && permissions.canManagePositions) ||
        (type === 'DELETE_CANDIDATE' && permissions.canManageCandidates) ||
        (type === 'DELETE_USER' && permissions.canManageUsers)
    ) {
        const entityType = type.split('_')[1].toLowerCase();
        const entityName = type === 'DELETE_USER' ? data.username : data.name;
        return (
             <Modal isOpen={isOpen} onClose={onClose} title={`Delete ${entityType}`}>
                <p>Are you sure you want to delete <strong>{entityName}</strong>? This action cannot be undone.</p>
                <div className="flex justify-end space-x-4 mt-6">
                    <Button variant="secondary" onClick={onClose}>Cancel</Button>
                    <Button variant="danger" onClick={() => {
                        if (type === 'DELETE_POSITION') handlers.onDeletePosition(data.id);
                        else if (type === 'DELETE_CANDIDATE') handlers.onDeleteCandidate(data.positionId, data.id);
                        else if (type === 'DELETE_USER') handlers.onDeleteUser(data.id);
                        onClose();
                    }}>Delete</Button>
                </div>
            </Modal>
        );
    }

    return null;
};

// Position Form Component
const PositionForm = ({ position, onSave, onCancel }: { position?: Position, onSave: (data: any) => void, onCancel: () => void }) => {
    const [name, setName] = useState(position?.name || '');
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ name });
    };
    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="pos-name" className="block text-sm font-medium text-gray-700">Position Name</label>
                <input type="text" id="pos-name" value={name} onChange={e => setName(e.target.value)} required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-dmi-blue-500 focus:ring-dmi-blue-500 sm:text-sm" />
            </div>
            <div className="flex justify-end space-x-4 pt-4">
                <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
                <Button type="submit">Save Position</Button>
            </div>
        </form>
    );
};

// Candidate Form Component
const CandidateForm = ({ candidate, onSave, onCancel }: { candidate?: Candidate, onSave: (data: any) => void, onCancel: () => void }) => {
    const [formData, setFormData] = useState({
        name: candidate?.name || '',
        faculty: candidate?.faculty || '',
        photoUrl: candidate?.photoUrl || null,
        manifesto: candidate?.manifesto || '',
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleImageChange = (base64Image: string) => {
        setFormData({ ...formData, photoUrl: base64Image });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData);
    };

    return (
         <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1">
                <ImageUploader imageUrl={formData.photoUrl} onImageChange={handleImageChange} />
            </div>
            <div className="md:col-span-2 space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700">Full Name</label>
                    <input type="text" name="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-dmi-blue-500 focus:ring-dmi-blue-500" />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700">Faculty</label>
                    <input type="text" name="faculty" value={formData.faculty} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-dmi-blue-500 focus:ring-dmi-blue-500" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700">Manifesto</label>
                    <textarea name="manifesto" value={formData.manifesto} onChange={handleChange} required rows={5} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-dmi-blue-500 focus:ring-dmi-blue-500" />
                </div>
            </div>
            <div className="md:col-span-3 flex justify-end space-x-4 pt-4 border-t mt-2">
                <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
                <Button type="submit">Save Candidate</Button>
            </div>
        </form>
    );
};

// User Form Component
const UserForm = ({ user, onSave, onCancel }: { user?: AdminUser, onSave: (data: any) => void, onCancel: () => void }) => {
    const [formData, setFormData] = useState({
        username: user?.username || '',
        password: '',
        role: user?.role || 'moderator',
    });
    const isEditing = !!user;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const dataToSave: any = { ...formData };
        if (isEditing && !formData.password) {
            delete dataToSave.password; // Don't update password if it's empty
        }
        onSave(dataToSave);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-gray-700">Username</label>
                <input type="text" name="username" value={formData.username} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-dmi-blue-500 focus:ring-dmi-blue-500" />
            </div>
            <div>
                <label className="block text-sm font-medium text-gray-700">Password</label>
                <input type="password" name="password" value={formData.password} onChange={handleChange} required={!isEditing} placeholder={isEditing ? 'Leave blank to keep current password' : ''} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-dmi-blue-500 focus:ring-dmi-blue-500" />
            </div>
             <div>
                <label className="block text-sm font-medium text-gray-700">Role</label>
                <select name="role" value={formData.role} onChange={handleChange} required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-dmi-blue-500 focus:ring-dmi-blue-500">
                    <option value="moderator">Moderator</option>
                    <option value="admin">Admin</option>
                    <option value="super_admin">Super Admin</option>
                </select>
            </div>
            <div className="flex justify-end space-x-4 pt-4">
                <Button type="button" variant="secondary" onClick={onCancel}>Cancel</Button>
                <Button type="submit">{isEditing ? 'Update User' : 'Create User'}</Button>
            </div>
        </form>
    );
}

export default AdminDashboard;
