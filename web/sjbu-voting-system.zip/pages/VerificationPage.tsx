import React, { useState } from 'react';
import { MOCK_VOTE_VERIFICATION_CODE } from '../constants';
import Button from '../components/Button';
import Card from '../components/Card';
import Spinner from '../components/Spinner';

const VerificationPage: React.FC = () => {
  const [code, setCode] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'verified' | 'error'>('idle');

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('loading');
    setTimeout(() => {
      if (code.toUpperCase() === MOCK_VOTE_VERIFICATION_CODE) {
        setStatus('verified');
      } else {
        setStatus('error');
      }
    }, 1500);
  };

  const renderIdle = () => (
    <form onSubmit={handleVerify}>
      <h2 className="text-2xl font-bold text-dmi-blue-900 mb-2">Vote Verification Portal</h2>
      <p className="text-gray-600 mb-6">Enter the verification code from your receipt to confirm your vote was counted.</p>
      <input
        type="text"
        value={code}
        onChange={(e) => setCode(e.target.value)}
        className="w-full text-center text-xl font-mono bg-gray-100 border-2 border-gray-300 rounded-lg p-3 focus:border-dmi-blue-500 focus:ring-dmi-blue-500 text-dmi-blue-900 font-semibold placeholder-gray-400"
        placeholder="SJBU-XXXX-XXXX"
        required
      />
      <p className="text-xs text-gray-500 mt-2">(Use demo code: {MOCK_VOTE_VERIFICATION_CODE})</p>
      <Button type="submit" className="w-full mt-6" size="lg" disabled={status === 'loading'}>
        {status === 'loading' ? <Spinner/> : 'Verify My Vote'}
      </Button>
    </form>
  );

  const renderResult = (isSuccess: boolean) => (
    <div className="text-center">
        {isSuccess ? 
            <svg className="w-16 h-16 text-green-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> :
            <svg className="w-16 h-16 text-red-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        }
      <h2 className={`text-2xl font-bold ${isSuccess ? 'text-green-700' : 'text-red-700'}`}>
        {isSuccess ? 'Vote Verified' : 'Verification Failed'}
      </h2>
      <p className="text-gray-600 mt-2">
        {isSuccess ? 'Your vote has been successfully counted in the election.' : 'The code you entered was not found in our system. Please check the code and try again.'}
      </p>
      {isSuccess && (
          <div className="text-left bg-gray-100 p-4 rounded-lg mt-4 text-sm text-gray-700 space-y-2">
              <p><strong>Verification Code:</strong> {MOCK_VOTE_VERIFICATION_CODE}</p>
              <p><strong>Vote Cast On:</strong> September 30, 2025 at 10:23 AM</p>
              <p><strong>Polling Station:</strong> Main Campus</p>
              <p className="text-xs text-gray-500 pt-2 border-t mt-2">Note: For your privacy and security, we do not display who you voted for.</p>
          </div>
      )}
      <Button onClick={() => { setCode(''); setStatus('idle'); }} className="w-full mt-6">
        Verify Another Code
      </Button>
    </div>
  );

  return (
    <div className="min-h-[60vh] flex items-center justify-center py-12 px-4">
      <Card className="max-w-lg w-full p-8">
        {status === 'idle' && renderIdle()}
        {status === 'loading' && <div className="flex justify-center items-center h-48"><Spinner /></div>}
        {status === 'verified' && renderResult(true)}
        {status === 'error' && renderResult(false)}
      </Card>
    </div>
  );
};

export default VerificationPage;