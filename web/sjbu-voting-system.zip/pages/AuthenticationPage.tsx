import React, { useState, useEffect } from 'react';
import { Page, ElectionStatus } from '../types';
import Button from '../components/Button';
import Card from '../components/Card';
import Spinner from '../components/Spinner';
import CountdownTimer from '../components/CountdownTimer';

interface AuthenticationPageProps {
  setPage: (page: Page) => void;
  electionStatus: ElectionStatus;
  electionStartDate: Date;
  electionEndDate: Date;
}

const MAX_ATTEMPTS = 5;
const LOCKOUT_MINUTES = 15;

const AuthenticationPage: React.FC<AuthenticationPageProps> = ({ setPage, electionStatus, electionStartDate, electionEndDate }) => {
  const [voucher, setVoucher] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [lockoutUntil, setLockoutUntil] = useState<Date | null>(null);

  const correctVoucher = 'SJBU-VOTE-2025';

  // Load state from localStorage on mount
  useEffect(() => {
    try {
      const savedAttempts = localStorage.getItem('dmi-auth-attempts');
      if (savedAttempts) {
        setFailedAttempts(parseInt(savedAttempts, 10));
      }

      const savedLockout = localStorage.getItem('dmi-auth-lockout');
      if (savedLockout) {
        const lockoutDate = new Date(savedLockout);
        if (lockoutDate > new Date()) {
          setLockoutUntil(lockoutDate);
        } else {
          // Lockout has expired, clear it
          localStorage.removeItem('dmi-auth-lockout');
          localStorage.removeItem('dmi-auth-attempts');
          setFailedAttempts(0);
        }
      }
    } catch (e) {
      console.error("Failed to read auth state from localStorage", e);
    }
  }, []);

  // Timer to update the lockout countdown
  useEffect(() => {
    if (!lockoutUntil) return;

    const interval = setInterval(() => {
      if (new Date() >= lockoutUntil) {
        // Lockout finished
        setLockoutUntil(null);
        setFailedAttempts(0);
        setError('');
        localStorage.removeItem('dmi-auth-lockout');
        localStorage.removeItem('dmi-auth-attempts');
        clearInterval(interval);
      } else {
        // Force re-render to update countdown
        setLockoutUntil(new Date(lockoutUntil.getTime()));
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [lockoutUntil]);

  const handleVerifyVoucher = (e: React.FormEvent) => {
    e.preventDefault();
    if (lockoutUntil) return;

    setError('');
    setIsLoading(true);
    setTimeout(() => {
      if (voucher.toUpperCase() === correctVoucher) {
        setIsSuccess(true);
        // Reset attempts on success
        setFailedAttempts(0);
        localStorage.removeItem('dmi-auth-attempts');
        localStorage.removeItem('dmi-auth-lockout');
        setTimeout(() => setPage(Page.Voting), 1500);
      } else {
        const newAttempts = failedAttempts + 1;
        setFailedAttempts(newAttempts);
        localStorage.setItem('dmi-auth-attempts', newAttempts.toString());
        
        if (newAttempts >= MAX_ATTEMPTS) {
          const lockoutDate = new Date(new Date().getTime() + LOCKOUT_MINUTES * 60 * 1000);
          setLockoutUntil(lockoutDate);
          localStorage.setItem('dmi-auth-lockout', lockoutDate.toISOString());
          setError(`Too many failed attempts. Please try again later.`);
        } else {
          setError(`Invalid voucher code. You have ${MAX_ATTEMPTS - newAttempts} attempts remaining.`);
        }
        setVoucher('');
      }
      setIsLoading(false);
    }, 1500);
  };

  const renderSuccessView = () => (
    <div className="p-8 text-center flex flex-col items-center justify-center h-full">
        <svg className="w-24 h-24 text-green-500 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        <h3 className="text-2xl font-semibold text-dmi-blue-900">Authentication Successful!</h3>
        <p className="text-gray-600 mt-2">You are verified. Loading your ballot now...</p>
    </div>
  );

  const renderLockoutView = () => {
    if (!lockoutUntil) return null;

    const timeLeft = Math.max(0, Math.floor((lockoutUntil.getTime() - new Date().getTime()) / 1000));
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;

    return (
      <div className="p-8 text-center flex flex-col items-center justify-center">
        <svg className="w-24 h-24 text-red-500 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        <h3 className="text-2xl font-semibold text-dmi-blue-900">Too Many Failed Attempts</h3>
        <p className="text-gray-600 mt-2">For security, access is temporarily locked. Please try again in:</p>
        <div className="text-4xl font-mono font-bold text-red-600 my-4">
          {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
        </div>
      </div>
    );
  };

  const renderVoucherView = () => (
    <form onSubmit={handleVerifyVoucher}>
      <div className="p-8 text-center">
        <h3 className="text-xl font-semibold text-dmi-blue-900">Voter Authentication</h3>
        <p className="text-gray-600 mt-2">Please enter your unique voting voucher code below to proceed.</p>
        <div className="my-6">
          <input
            type="text"
            value={voucher}
            onChange={(e) => setVoucher(e.target.value)}
            className="w-full text-center text-2xl tracking-widest font-mono bg-gray-100 border-2 border-gray-300 rounded-lg p-3 focus:border-dmi-blue-500 focus:ring-dmi-blue-500 text-dmi-blue-900 font-semibold placeholder-gray-400 disabled:bg-gray-200 disabled:cursor-not-allowed"
            placeholder="ENTER VOUCHER"
            required
            autoFocus
            disabled={!!lockoutUntil || isLoading}
          />
           <p className="text-xs text-gray-500 mt-2">(Use demo code: SJBU-VOTE-2025)</p>
        </div>
        {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
      </div>
      <div className="bg-gray-50 px-8 py-4">
        <Button type="submit" className="w-full" disabled={isLoading || !!lockoutUntil}>
           {isLoading ? <Spinner/> : <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>}
          {isLoading ? 'Verifying...' : 'Verify & Proceed'}
        </Button>
      </div>
    </form>
  );

  const renderPageContent = () => {
    switch (electionStatus) {
      case 'PRE_ELECTION':
        return (
          <Card className="max-w-2xl mx-auto p-12 text-center bg-dmi-blue-800 text-white">
            <h2 className="text-3xl font-bold">The Election Has Not Started Yet</h2>
            <p className="mt-4 mb-8">Please check back when the countdown finishes. You will be able to cast your vote then.</p>
            <CountdownTimer targetDate={electionStartDate} title="Voting Begins In" onCompleteMessage="The Election is Now Live!" />
          </Card>
        );
      case 'POST_ELECTION':
        return (
          <Card className="max-w-md w-full p-12 text-center">
            <h2 className="text-3xl font-bold text-dmi-blue-900">Voting Has Ended</h2>
            <p className="text-gray-600 mt-4">The voting period for the 2025 Student Elections is now closed. Thank you for your participation.</p>
            <Button className="mt-6" onClick={() => setPage(Page.Results)}>View Official Results</Button>
          </Card>
        );
      case 'LIVE':
        return (
          <div className="max-w-md w-full space-y-8">
              <div className="p-4 bg-dmi-blue-700 rounded-xl">
                  <CountdownTimer targetDate={electionEndDate} title="Voting Closes In" onCompleteMessage="Voting has ended." />
              </div>
              <Card>
                  {lockoutUntil ? renderLockoutView() : (isSuccess ? renderSuccessView() : renderVoucherView())}
              </Card>
          </div>
        );
      default:
        return null;
    }
  }

  return (
    <div className="min-h-[60vh] flex items-center justify-center py-12 px-4">
        {renderPageContent()}
    </div>
  );
};

export default AuthenticationPage;