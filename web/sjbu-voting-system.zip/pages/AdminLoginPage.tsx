import React, { useState } from 'react';
import { AdminUser } from '../types';
import Button from '../components/Button';
import Card from '../components/Card';
import Spinner from '../components/Spinner';

interface AdminLoginPageProps {
  adminUsers: AdminUser[];
  onLoginSuccess: (user: AdminUser) => void;
}

const AdminLoginPage: React.FC<AdminLoginPageProps> = ({ adminUsers, onLoginSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Simulates /admin/login and /admin/profile
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    setTimeout(() => {
      const foundUser = adminUsers.find(user => user.username === username);

      if (foundUser && foundUser.password === password) {
        // Successful login, simulate fetching profile and setting user state
        const { password, ...userProfile } = foundUser;
        onLoginSuccess(userProfile as AdminUser);
      } else {
        setError('Invalid username or password.');
      }
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-[60vh] flex items-center justify-center py-12 px-4 bg-gray-50">
      <div className="max-w-md w-full">
        <h2 className="text-center text-3xl font-extrabold text-dmi-blue-900 mb-6">
          Admin Portal Login
        </h2>
        <Card>
          <form onSubmit={handleLogin}>
            <div className="p-8 space-y-6">
              <div>
                <label
                  htmlFor="username"
                  className="block text-sm font-medium text-gray-700"
                >
                  Username
                </label>
                <input
                  id="username"
                  name="username"
                  type="text"
                  autoComplete="username"
                  required
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  className="mt-1 appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-dmi-blue-500 focus:border-dmi-blue-500 sm:text-sm"
                />
              </div>

              <div>
                <label
                  htmlFor="password"
                  className="block text-sm font-medium text-gray-700"
                >
                  Password
                </label>
                <input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="mt-1 appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-dmi-blue-500 focus:border-dmi-blue-500 sm:text-sm"
                />
              </div>

              {error && <p className="text-sm text-red-600">{error}</p>}
               <p className="text-xs text-gray-500 mt-2">(Demo: super.admin / password123)</p>
            </div>
            <div className="bg-gray-50 px-8 py-4">
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? <Spinner /> : 'Sign In'}
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default AdminLoginPage;
