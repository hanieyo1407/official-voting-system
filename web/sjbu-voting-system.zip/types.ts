// FIX: Removed a self-referential import of `Page` that was causing a conflict with the enum declaration below.
export enum Page {
  Intro,
  Home,
  Authentication,
  Voting,
  VoteSuccess,
  Verification,
  Results,
  Winners,
  AdminLogin,
  Admin,
}

export type AdminRole = 'super_admin' | 'admin' | 'moderator';

export interface AdminUser {
  id: string;
  username: string;
  role: AdminRole;
  password?: string; // For mock authentication
}

export interface Candidate {
  id:string;
  name: string;
  photoUrl: string;
  faculty: string;
  manifesto: string;
}

export interface Position {
  id: string;
  name: string;
  candidates: Candidate[];
}

export interface VoteSelection {
  [positionId: string]: string | 'abstain'; // candidateId or 'abstain'
}

// API-Aligned Types for Statistics
export interface CandidateStats {
    candidateName: string;
    voteCount: number;
    votePercentage: number;
}

export interface PositionStats {
    positionName: string;
    totalVotes: number;
    candidates: CandidateStats[];
}

export interface OverallStats {
    totalPositions: number;
    totalCandidates: number;
}

export interface VotingStats {
    totalVoters: number;
    totalVotesCast: number;
    voterTurnout: number;
    positionsWithStats: PositionStats[];
    overallStats: OverallStats;
}

export type ElectionStatus = 'PRE_ELECTION' | 'LIVE' | 'POST_ELECTION';

export interface AuditLogEntry {
  id: string;
  timestamp: Date;
  adminUsername: string;
  action: string;
  details: string;
  ipAddress: string;
}